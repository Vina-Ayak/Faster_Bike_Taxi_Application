package com.examly.springapp.service;

import com.examly.springapp.model.Biketaxi;
import com.examly.springapp.repository.BiketaxiRepo;
import com.examly.springapp.model.DriverApplicationStatus;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BiketaxiService {

    @Autowired
    private BiketaxiRepo biketaxiRepo;

    public boolean addBiketaxi(Biketaxi biketaxi) {
        try {
            biketaxiRepo.save(biketaxi);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<Biketaxi> getAllBiketaxi() {
        return biketaxiRepo.findAll();
    }

    public List<Biketaxi> getBiketaxisByUserId(Integer userId) {
        return biketaxiRepo.findByUserId(userId);
    }

    public List<Biketaxi> getBiketaxisByStatus(DriverApplicationStatus status) {
        return biketaxiRepo.findByStatus(status);
    }

    public Optional<Biketaxi> getBiketaxiById(int id) {
        return biketaxiRepo.findById(id);
    }

    public Biketaxi updateApplicationStatus(int id, DriverApplicationStatus newStatus) {
        return biketaxiRepo.findById(id).map(biketaxi -> {
            biketaxi.setStatus(newStatus);
            return biketaxiRepo.save(biketaxi);
        }).orElseThrow(() -> new RuntimeException("Application not found"));
    }
}
