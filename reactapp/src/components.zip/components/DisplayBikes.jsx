import React, { useEffect, useState } from 'react';
import { color, font, radius, shadow, pageShell, statusStyles, fontImports } from './theme';

function DisplayBikes() {
  const [bikes, setBikes] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    fetch('/getAllBiketaxi', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : ''
      },
    })
      .then(res => res.json())
      .then(data => setBikes(data))
      .catch(err => console.error(err));
  }, []);

  const styles = {
    page: { ...pageShell, padding: '40px 28px' },
    header: { display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', maxWidth: '1000px', margin: '0 auto 18px auto' },
    heading: { fontFamily: font.display, fontSize: '1.4rem', fontWeight: 600, margin: 0, color: color.ink },
    count: { fontSize: '0.85rem', color: color.inkMuted },
    card: {
      maxWidth: '1000px',
      margin: '0 auto',
      backgroundColor: color.surface,
      border: `1px solid ${color.border}`,
      borderRadius: radius.lg,
      boxShadow: shadow.card,
      overflow: 'hidden',
    },
    table: { width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' },
    th: {
      textAlign: 'left',
      padding: '12px 18px',
      backgroundColor: color.surfaceSunken,
      borderBottom: `1px solid ${color.border}`,
      color: color.inkMuted,
      fontWeight: 600,
      fontSize: '0.75rem',
      textTransform: 'uppercase',
      letterSpacing: '0.03em',
    },
    td: {
      padding: '12px 18px',
      borderBottom: `1px solid ${color.border}`,
      color: color.ink,
    },
  };

  return (
    <div style={styles.page}>
      <style>{fontImports}</style>
      <div style={styles.header}>
        <h2 style={styles.heading}>Submitted applications</h2>
        <span style={styles.count}>{bikes.length} total</span>
      </div>
      <div style={styles.card}>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Name</th>
              <th style={styles.th}>Bike number</th>
              <th style={styles.th}>Age</th>
              <th style={styles.th}>Phone number</th>
              <th style={styles.th}>Status</th>
            </tr>
          </thead>
          <tbody>
            {bikes && bikes.map((bike, index) => (
              <tr key={index}>
                <td style={styles.td}>{bike.name}</td>
                <td style={styles.td}>{bike.bikeNumber}</td>
                <td style={styles.td}>{bike.age}</td>
                <td style={styles.td}>{bike.phoneNumber}</td>
                <td style={styles.td}>
                  <span style={statusStyles(bike.status)}>{bike.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default DisplayBikes;
