import React from 'react';
import { Link } from 'react-router-dom';
import { color, font } from './theme';

function NavBar() {
  const styles = {
    nav: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      backgroundColor: color.navy,
      padding: '0 28px',
      height: '58px',
      fontFamily: font.body,
      position: 'sticky',
      top: 0,
      zIndex: 1000,
    },
    logo: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      color: '#fff',
      textDecoration: 'none',
      fontSize: '0.95rem',
      fontWeight: 600,
      fontFamily: font.display,
      letterSpacing: '-0.01em',
    },
    mark: {
      width: '8px',
      height: '8px',
      borderRadius: '2px',
      backgroundColor: color.amber,
    },
    navLinks: {
      display: 'flex',
      alignItems: 'center',
      listStyle: 'none',
      gap: '28px',
      margin: 0,
      padding: 0,
    },
    link: {
      color: '#AEB6C4',
      textDecoration: 'none',
      fontSize: '0.85rem',
      fontWeight: 500,
    },
    applyButton: {
      backgroundColor: '#fff',
      color: color.navy,
      padding: '7px 16px',
      borderRadius: '4px',
      textDecoration: 'none',
      fontSize: '0.82rem',
      fontWeight: 600,
    }
  };

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.logo}>
        <span style={styles.mark} />
        Faster Bike Taxi
      </Link>

      <ul style={styles.navLinks}>
        <li><Link to="/bikedetails" style={styles.link}>Fleet</Link></li>
        <li><Link to="/operations" style={styles.link}>Operations</Link></li>
        <li><Link to="/auth" style={styles.link}>Sign in</Link></li>
      </ul>

      <div>
        <Link to="/apply" style={styles.applyButton}>Apply as driver</Link>
      </div>
    </nav>
  );
}

export default NavBar;
