import React, { useState } from 'react';
import * as api from '../api/api';
import { color, font, radius, shadow, pageShell, secondaryButton, statusStyles, fontImports } from './theme';

function Operations() {
  const [logs, setLogs] = useState([]);
  const [stats, setStats] = useState(null);
  const [applications, setApplications] = useState([]);

  const fetchLogs = async () => {
    try {
      const res = await api.getAuditLogs();
      const data = await res.json();
      setLogs(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await api.getMyPerformance();
      const data = await res.json();
      setStats(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchApplications = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/getAllBiketaxi', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setApplications(data);
      } else {
        alert('Failed to load apps. Are you an Admin?');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateStatus = async (id, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/biketaxi/${id}/status?status=${newStatus}`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        alert('Status updated successfully!');
        fetchApplications();
      } else {
        alert('Failed to update status');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const styles = {
    page: { ...pageShell, padding: '40px 28px' },
    wrap: { maxWidth: '1080px', margin: '0 auto' },
    heading: { fontFamily: font.display, fontSize: '1.4rem', fontWeight: 600, margin: '0 0 4px 0', color: color.ink },
    sub: { fontSize: '0.85rem', color: color.inkMuted, margin: '0 0 22px 0' },
    actionRow: { display: 'flex', gap: '10px', marginBottom: '26px' },
    panel: {
      backgroundColor: color.surface,
      border: `1px solid ${color.border}`,
      borderRadius: radius.lg,
      boxShadow: shadow.card,
      padding: '18px 20px',
      marginBottom: '20px',
      fontFamily: font.mono,
      fontSize: '0.78rem',
      color: color.inkMuted,
      whiteSpace: 'pre-wrap',
    },
    card: {
      backgroundColor: color.surface,
      border: `1px solid ${color.border}`,
      borderRadius: radius.lg,
      boxShadow: shadow.card,
      overflow: 'hidden',
    },
    table: { width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' },
    th: {
      textAlign: 'left',
      padding: '12px 18px',
      backgroundColor: color.surfaceSunken,
      borderBottom: `1px solid ${color.border}`,
      color: color.inkMuted,
      fontWeight: 600,
      fontSize: '0.75rem',
      textTransform: 'uppercase',
      letterSpacing: '0.03em',
    },
    td: { padding: '12px 18px', borderBottom: `1px solid ${color.border}`, color: color.ink },
    select: {
      padding: '6px 10px',
      fontSize: '0.8rem',
      fontFamily: font.body,
      border: `1px solid ${color.borderStrong}`,
      borderRadius: radius.sm,
      color: color.ink,
      background: color.surface,
    },
  };

  return (
    <div style={styles.page}>
      <style>{fontImports}</style>
      <div style={styles.wrap}>
        <h2 style={styles.heading}>Operations dashboard</h2>
        <p style={styles.sub}>Review driver performance, audit activity, and manage application status.</p>

        <div style={styles.actionRow}>
          <button onClick={fetchStats} style={secondaryButton}>Load my performance</button>
          <button onClick={fetchLogs} style={secondaryButton}>Load audit logs</button>
          <button onClick={fetchApplications} style={secondaryButton}>Load applications (admin)</button>
        </div>

        {stats && <div style={styles.panel}>{JSON.stringify(stats, null, 2)}</div>}
        {logs.length > 0 && (
          <div style={styles.panel}>
            {logs.map((log, idx) => <div key={idx}>{JSON.stringify(log)}</div>)}
          </div>
        )}

        {applications.length > 0 && (
          <div style={styles.card}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>ID</th>
                  <th style={styles.th}>Name</th>
                  <th style={styles.th}>Bike number</th>
                  <th style={styles.th}>Status</th>
                  <th style={styles.th}>Action</th>
                </tr>
              </thead>
              <tbody>
                {applications.map(app => (
                  <tr key={app.id}>
                    <td style={styles.td}>{app.id}</td>
                    <td style={styles.td}>{app.name}</td>
                    <td style={styles.td}>{app.bikeNumber}</td>
                    <td style={styles.td}><span style={statusStyles(app.status)}>{app.status}</span></td>
                    <td style={styles.td}>
                      <select
                        style={styles.select}
                        defaultValue={app.status}
                        onChange={(e) => handleUpdateStatus(app.id, e.target.value)}
                      >
                        <option value="DRAFT">DRAFT</option>
                        <option value="SUBMITTED">SUBMITTED</option>
                        <option value="UNDER_REVIEW">UNDER_REVIEW</option>
                        <option value="DOCUMENT_VERIFICATION">DOCUMENT_VERIFICATION</option>
                        <option value="BACKGROUND_CHECK">BACKGROUND_CHECK</option>
                        <option value="APPROVED">APPROVED</option>
                        <option value="REJECTED">REJECTED</option>
                        <option value="ON_HOLD">ON_HOLD</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default Operations;
