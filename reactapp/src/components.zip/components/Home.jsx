import React from 'react';
import { Link } from 'react-router-dom';
import { color, font, radius, fontImports } from './theme';

function Home() {
  const styles = {
    container: {
      fontFamily: font.body,
      backgroundColor: color.navy,
      color: '#fff',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      padding: '0 20px',
    },
    eyebrow: {
      color: color.amber,
      fontSize: '0.85rem',
      fontWeight: 600,
      margin: '0 0 14px 0',
    },
    title: {
      fontFamily: font.display,
      fontSize: '3.25rem',
      fontWeight: 700,
      letterSpacing: '-0.02em',
      margin: '0 0 16px 0',
    },
    subtitle: {
      fontSize: '1.05rem',
      fontWeight: 400,
      color: '#AEB6C4',
      maxWidth: '540px',
      margin: '0 0 36px 0',
      lineHeight: 1.6,
    },
    buttonContainer: {
      display: 'flex',
      gap: '14px',
    },
    primaryButton: {
      backgroundColor: '#fff',
      color: color.navy,
      padding: '12px 22px',
      borderRadius: radius.sm,
      textDecoration: 'none',
      fontSize: '0.9rem',
      fontWeight: 600,
    },
    secondaryButton: {
      backgroundColor: 'transparent',
      color: '#fff',
      padding: '12px 22px',
      borderRadius: radius.sm,
      textDecoration: 'none',
      fontSize: '0.9rem',
      fontWeight: 600,
      border: `1px solid ${color.navySoft}`,
    }
  };

  return (
    <div style={styles.container}>
      <style>{fontImports}</style>
      <p style={styles.eyebrow}>Faster Bike Taxi</p>
      <h1 style={styles.title}>Fleet operations, built for scale.</h1>
      <h2 style={styles.subtitle}>
        Manage driver onboarding, compliance, and fleet performance in one place.
      </h2>
      <div style={styles.buttonContainer}>
        <Link to="/apply" style={styles.primaryButton}>Apply now</Link>
        <Link to="/bikedetails" style={styles.secondaryButton}>Learn more</Link>
      </div>
    </div>
  );
}

export default Home;
