import React, { useState } from 'react';
import { addBiketaxi } from '../api/api';
import { color, font, radius, shadow, inputStyle, labelStyle, primaryButton, pageShell, fontImports } from './theme';

function ApplyForm() {
  const [formData, setFormData] = useState({
    name: '',
    bikeNumber: '',
    age: '',
    phoneNumber: ''
  });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value});
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let newErrors = {};
    if (!formData.name) newErrors.name = 'Name is required';
    if (!formData.bikeNumber) newErrors.bikeNumber = 'Bike number is required';
    if (!formData.age) newErrors.age = 'Age is required';
    if (!formData.phoneNumber) newErrors.phoneNumber = 'Phone number is required';

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('Please login first to submit an application!');
        return;
      }

      try {
        const payload = {...formData, age: Number(formData.age)};
        const res = await addBiketaxi(payload);

        if (res.ok) {
          setSuccess(true);
        } else {
          const errText = await res.text();
          if (res.status === 500) {
            alert('Failed to submit: This bike number might already be registered, or there is a server error.');
          } else {
            alert('Failed to submit: ' + errText);
          }
        }
      } catch (err) {
        console.error(err);
        alert('Network error occurred. ' + err);
      }
    }
  };

  const styles = {
    page: { ...pageShell, padding: '56px 20px', display: 'flex', justifyContent: 'center' },
    card: {
      width: '100%',
      maxWidth: '520px',
      backgroundColor: color.surface,
      border: `1px solid ${color.border}`,
      borderRadius: radius.lg,
      boxShadow: shadow.card,
      padding: '36px',
    },
    heading: {
      fontFamily: font.display,
      fontSize: '1.4rem',
      fontWeight: 600,
      margin: '0 0 4px 0',
      color: color.ink,
    },
    sub: {
      fontSize: '0.85rem',
      color: color.inkMuted,
      margin: '0 0 26px 0',
    },
    success: {
      backgroundColor: '#E5F5EC',
      color: '#0F6E3D',
      border: '1px solid #BEE6CE',
      borderRadius: radius.sm,
      padding: '12px 14px',
      fontSize: '0.85rem',
      fontWeight: 500,
      marginBottom: '20px',
    },
    field: { display: 'flex', flexDirection: 'column', marginBottom: '16px' },
    error: { color: color.danger, fontSize: '0.78rem', marginTop: '4px' },
    grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
  };

  return (
    <div style={styles.page}>
      <style>{fontImports}</style>
      <div style={styles.card}>
        <h2 style={styles.heading}>Driver application</h2>
        <p style={styles.sub}>Provide your details to join the fleet. Applications are reviewed by our operations team.</p>

        {success && <div style={styles.success}>Your application has been submitted successfully.</div>}

        <form onSubmit={handleSubmit}>
          <div style={styles.field}>
            <label style={labelStyle} htmlFor="name">Full name</label>
            <input style={inputStyle} type="text" id="name" name="name" value={formData.name} onChange={handleChange} />
            {errors.name && <span style={styles.error}>{errors.name}</span>}
          </div>
          <div style={styles.grid}>
            <div style={styles.field}>
              <label style={labelStyle} htmlFor="bikeNumber">Bike number</label>
              <input style={inputStyle} type="text" id="bikeNumber" name="bikeNumber" value={formData.bikeNumber} onChange={handleChange} />
              {errors.bikeNumber && <span style={styles.error}>{errors.bikeNumber}</span>}
            </div>
            <div style={styles.field}>
              <label style={labelStyle} htmlFor="age">Age</label>
              <input style={inputStyle} type="number" id="age" name="age" value={formData.age} onChange={handleChange} />
              {errors.age && <span style={styles.error}>{errors.age}</span>}
            </div>
          </div>
          <div style={styles.field}>
            <label style={labelStyle} htmlFor="phoneNumber">Phone number</label>
            <input style={inputStyle} type="text" id="phoneNumber" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} />
            {errors.phoneNumber && <span style={styles.error}>{errors.phoneNumber}</span>}
          </div>
          <button style={{ ...primaryButton, width: '100%', padding: '12px', marginTop: '8px' }} type="submit">Submit application</button>
        </form>
      </div>
    </div>
  );
}

export default ApplyForm;
