import React, { useState } from 'react';
import { register, login } from '../api/api';
import { color, font, radius, shadow, inputStyle, labelStyle, primaryButton, secondaryButton, pageShell, fontImports } from './theme';

function Auth() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [role, setRole] = useState('DRIVER');
  const [profile, setProfile] = useState(null);
  const [token, setToken] = useState('');

  const handleRegister = async () => {
    try {
      const res = await register({ username, email, password, phoneNumber, role });
      if (res.ok) {
        const data = await res.json();
        setToken(data.token);
        localStorage.setItem('token', data.token);
        alert(`Registered successfully as ${role}!`);
      } else {
        alert('Failed to register: ' + await res.text());
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogin = async () => {
    try {
      const res = await login({ username, password });
      if (res.ok) {
        const data = await res.json();
        setToken(data.token);
        localStorage.setItem('token', data.token);
        alert('Logged in successfully!');
      } else {
        alert('Failed to login: ' + await res.text());
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchProfile = async () => {
    try {
      const currentToken = localStorage.getItem('token') || token;
      const res = await fetch('/api/auth/profile', {
        headers: { 'Authorization': 'Bearer ' + currentToken }
      });
      if (res.ok) {
        const data = await res.json();
        setProfile(data);
      } else {
        alert('Failed to get profile: ' + await res.text());
      }
    } catch (e) {
      console.error(e);
    }
  };

  const styles = {
    page: { ...pageShell, padding: '56px 20px', display: 'flex', justifyContent: 'center' },
    card: {
      width: '100%',
      maxWidth: '400px',
      backgroundColor: color.surface,
      border: `1px solid ${color.border}`,
      borderRadius: radius.lg,
      boxShadow: shadow.card,
      padding: '32px',
    },
    heading: {
      fontFamily: font.display,
      fontSize: '1.4rem',
      fontWeight: 600,
      margin: '0 0 4px 0',
      color: color.ink,
    },
    sub: {
      fontSize: '0.85rem',
      color: color.inkMuted,
      margin: '0 0 24px 0',
    },
    field: { display: 'flex', flexDirection: 'column', marginBottom: '14px' },
    select: { ...inputStyle },
    row: { display: 'flex', gap: '10px', marginTop: '6px' },
    divider: { borderTop: `1px solid ${color.border}`, margin: '28px 0 20px 0' },
    profileBox: {
      fontFamily: font.mono,
      fontSize: '0.78rem',
      backgroundColor: color.surfaceSunken,
      border: `1px solid ${color.border}`,
      borderRadius: radius.sm,
      padding: '12px',
      marginTop: '14px',
      whiteSpace: 'pre-wrap',
      color: color.inkMuted,
    },
  };

  return (
    <div style={styles.page}>
      <style>{fontImports}</style>
      <div style={styles.card}>
        <h2 style={styles.heading}>Sign in to Fleet Ops</h2>
        <p style={styles.sub}>Access your driver or admin account.</p>

        <div style={styles.field}>
          <label style={labelStyle}>Username</label>
          <input style={inputStyle} type="text" value={username} onChange={e => setUsername(e.target.value)} />
        </div>
        <div style={styles.field}>
          <label style={labelStyle}>Email <span style={{ fontWeight: 400 }}>(registration only)</span></label>
          <input style={inputStyle} type="text" value={email} onChange={e => setEmail(e.target.value)} />
        </div>
        <div style={styles.field}>
          <label style={labelStyle}>Password</label>
          <input style={inputStyle} type="password" value={password} onChange={e => setPassword(e.target.value)} />
        </div>
        <div style={styles.field}>
          <label style={labelStyle}>Phone number <span style={{ fontWeight: 400 }}>(registration only)</span></label>
          <input style={inputStyle} type="text" value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} />
        </div>
        <div style={styles.field}>
          <label style={labelStyle}>Role</label>
          <select style={styles.select} value={role} onChange={e => setRole(e.target.value)}>
            <option value="DRIVER">Driver</option>
            <option value="ADMIN">Admin</option>
          </select>
        </div>

        <div style={styles.row}>
          <button onClick={handleRegister} style={{ ...secondaryButton, flex: 1 }}>Register</button>
          <button onClick={handleLogin} style={{ ...primaryButton, flex: 1 }}>Login</button>
        </div>

        <div style={styles.divider} />

        <button onClick={fetchProfile} style={secondaryButton}>View profile</button>
        {profile && <pre style={styles.profileBox}>{JSON.stringify(profile, null, 2)}</pre>}
      </div>
    </div>
  );
}

export default Auth;
