import React from 'react';
import { Link } from 'react-router-dom';
import { color, font, radius, shadow, fontImports } from './theme';

function LandingPage() {
  const styles = {
    container: {
      fontFamily: font.body,
      backgroundColor: color.navy,
      color: '#fff',
      minHeight: 'calc(100vh - 58px)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 60px',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: '1.1fr 0.9fr',
      gap: '64px',
      alignItems: 'center',
      maxWidth: '1100px',
      margin: '0 auto',
      width: '100%',
    },
    eyebrow: {
      color: color.amber,
      fontSize: '0.85rem',
      fontWeight: 600,
      margin: '0 0 14px 0',
    },
    title: {
      fontFamily: font.display,
      fontSize: '3rem',
      fontWeight: 700,
      lineHeight: 1.1,
      letterSpacing: '-0.02em',
      margin: '0 0 18px 0',
      maxWidth: '480px',
    },
    subtitle: {
      fontSize: '1.05rem',
      fontWeight: 400,
      color: '#AEB6C4',
      maxWidth: '460px',
      margin: '0 0 32px 0',
      lineHeight: 1.6,
    },
    actions: {
      display: 'flex',
      gap: '14px',
    },
    primaryButton: {
      backgroundColor: '#fff',
      color: color.navy,
      padding: '12px 22px',
      borderRadius: radius.sm,
      textDecoration: 'none',
      fontSize: '0.9rem',
      fontWeight: 600,
    },
    secondaryButton: {
      backgroundColor: 'transparent',
      color: '#fff',
      padding: '12px 22px',
      borderRadius: radius.sm,
      textDecoration: 'none',
      fontSize: '0.9rem',
      fontWeight: 600,
      border: `1px solid ${color.navySoft}`,
    },
    panel: {
      backgroundColor: '#131C2E',
      border: `1px solid ${color.navySoft}`,
      borderRadius: radius.lg,
      padding: '24px',
      boxShadow: shadow.card,
    },
    panelHead: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '18px',
      paddingBottom: '14px',
      borderBottom: `1px solid ${color.navySoft}`,
    },
    panelTitle: {
      fontSize: '0.8rem',
      color: '#AEB6C4',
      fontWeight: 500,
    },
    live: {
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      fontSize: '0.75rem',
      color: '#7CD98A',
    },
    dot: {
      width: '6px',
      height: '6px',
      borderRadius: '50%',
      backgroundColor: '#3DBB5A',
    },
    statRow: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '18px',
    },
    statValue: {
      fontFamily: font.display,
      fontSize: '1.9rem',
      fontWeight: 700,
    },
    statLabel: {
      fontSize: '0.78rem',
      color: '#8792A2',
      marginTop: '4px',
    },
  };

  return (
    <div style={styles.container}>
      <style>{fontImports}</style>
      <div style={styles.grid}>
        <div>
          <p style={styles.eyebrow}>Urban mobility operations</p>
          <h1 style={styles.title}>Run a compliant, high-uptime bike taxi fleet.</h1>
          <p style={styles.subtitle}>
            Onboard drivers, verify documentation, and track fleet performance from a single operations console.
          </p>
          <div style={styles.actions}>
            <Link to="/apply" style={styles.primaryButton}>Apply as a driver</Link>
            <Link to="/bikedetails" style={styles.secondaryButton}>View fleet details</Link>
          </div>
        </div>

        <div style={styles.panel}>
          <div style={styles.panelHead}>
            <span style={styles.panelTitle}>Fleet status</span>
            <span style={styles.live}><span style={styles.dot} />Live</span>
          </div>
          <div style={styles.statRow}>
            <div>
              <div style={styles.statValue}>1,204</div>
              <div style={styles.statLabel}>Active drivers</div>
            </div>
            <div>
              <div style={styles.statValue}>98.4%</div>
              <div style={styles.statLabel}>Verification rate</div>
            </div>
            <div>
              <div style={styles.statValue}>3.2 min</div>
              <div style={styles.statLabel}>Avg. review time</div>
            </div>
            <div>
              <div style={styles.statValue}>24</div>
              <div style={styles.statLabel}>Cities served</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LandingPage;
